<footer class="dashboard">
        <p>&copy 2022 <span class="text-warning"><b>E-Petshop</b></span></p>
    </footer>